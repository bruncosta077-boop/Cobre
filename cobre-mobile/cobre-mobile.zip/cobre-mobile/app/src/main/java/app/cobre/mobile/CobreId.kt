package app.cobre.mobile

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class CobreIdException(val status: Int, val code: String, message: String) : Exception(message)

data class Device(
    val id: String, val name: String, val type: String,
    val online: Boolean, val lastSeen: Long, val current: Boolean,
)

/**
 * Cliente do Cobre ID (mesmo contrato do Desktop e do servidor).
 * - Refresh token: cifrado pelo Keystore. Access token: só em memória.
 * - Falta de rede NUNCA desloga; só um 401 do servidor encerra a sessão.
 */
class CobreId(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("cobre_id", Context.MODE_PRIVATE)
    private val lock = Mutex()
    private var access: String? = null
    private var accessExp = 0L

    var server: String
        get() = sp.getString("server", "") ?: ""
        set(v) { sp.edit().putString("server", v.trim().trimEnd('/')).apply() }
    val email: String get() = sp.getString("email", "") ?: ""
    val deviceId: String? get() = sp.getString("device", null)
    val loggedIn: Boolean get() = sp.contains("refresh")

    private fun readRefresh(): String? = sp.getString("refresh", null)?.let { Vault.open(it) }

    private fun clear() {
        access = null
        sp.edit().remove("refresh").apply()
    }

    private fun adopt(j: JSONObject) {
        access = j.getString("accessToken")
        accessExp = System.currentTimeMillis() + (j.getLong("expiresIn") - 15) * 1000
        // refresh rotativo: grava o novo ANTES de qualquer outro uso
        val e = sp.edit()
            .putString("refresh", Vault.seal(j.getString("refreshToken")))
            .putString("device", j.getJSONObject("device").getString("id"))
        j.optJSONObject("user")?.optString("email")?.takeIf { it.isNotEmpty() }?.let { e.putString("email", it) }
        e.apply()
    }

    private suspend fun raw(method: String, path: String, body: JSONObject?, token: String?): JSONObject =
        withContext(Dispatchers.IO) {
            if (server.isEmpty()) throw CobreIdException(0, "no_server", "Informe o endereço do servidor.")
            val conn = try {
                URL(server + path).openConnection() as HttpURLConnection
            } catch (e: Exception) {
                throw CobreIdException(0, "bad_server", "Endereço do servidor inválido.")
            }
            try {
                conn.requestMethod = method
                conn.connectTimeout = 8000
                conn.readTimeout = 15000
                conn.setRequestProperty("Content-Type", "application/json")
                token?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
                if (body != null) {
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                val json = runCatching { JSONObject(text) }.getOrDefault(JSONObject())
                if (code !in 200..299) {
                    throw CobreIdException(code, json.optString("error", "http_$code"), json.optString("message", "Erro $code"))
                }
                json
            } catch (e: CobreIdException) {
                throw e
            } catch (e: IOException) {
                throw CobreIdException(0, "network", "Sem conexão com o servidor do Cobre.")
            } finally {
                conn.disconnect()
            }
        }

    suspend fun signIn(serverUrl: String, email: String, password: String, create: Boolean) {
        server = serverUrl
        val dev = JSONObject().put("name", Build.MODEL ?: "Celular").put("type", "mobile")
        deviceId?.let { dev.put("id", it) }
        val body = JSONObject().put("email", email.trim()).put("password", password).put("device", dev)
        adopt(raw("POST", if (create) "/v1/register" else "/v1/login", body, null))
    }

    private suspend fun ensureAccess(): String = lock.withLock {
        val a = access
        if (a != null && System.currentTimeMillis() < accessExp) return@withLock a
        val r = readRefresh()
        if (r == null) { clear(); throw CobreIdException(401, "signed_out", "Entre na sua conta Cobre.") }
        try {
            adopt(raw("POST", "/v1/refresh", JSONObject().put("refreshToken", r), null))
        } catch (e: CobreIdException) {
            if (e.status == 401) clear()   // sessão morreu de verdade; erro de rede não passa por aqui
            throw e
        }
        access!!
    }

    private suspend fun auth(method: String, path: String, body: JSONObject? = null): JSONObject {
        try {
            return raw(method, path, body, ensureAccess())
        } catch (e: CobreIdException) {
            if (e.code == "device_revoked") clear()
            if (e.status == 401 && e.code == "unauthorized" && loggedIn) {
                access = null
                return raw(method, path, body, ensureAccess())
            }
            throw e
        }
    }

    suspend fun devices(): List<Device> {
        val arr = auth("GET", "/v1/devices").getJSONArray("devices")
        return (0 until arr.length()).map {
            val d = arr.getJSONObject(it)
            Device(
                d.getString("id"), d.getString("name"), d.getString("type"),
                d.getBoolean("online"), d.optLong("lastSeen", 0), d.getBoolean("current"),
            )
        }
    }

    suspend fun removeDevice(id: String) { auth("DELETE", "/v1/devices/$id") }

    suspend fun presence() {
        auth("POST", "/v1/presence", JSONObject().put("meta", JSONObject().put("app", "mobile-0.2.0")))
    }

    suspend fun signOut() {
        runCatching { auth("POST", "/v1/logout", JSONObject()) }
        clear()
        sp.edit().remove("device").apply()
    }
}

package app.cobre.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Panel = Color(0xFF181614); private val Tx = Color(0xFFECE6DF)
private val Mu = Color(0xFF8D847B); private val Cu = Color(0xFFC9773F); private val Ok = Color(0xFF5FB37A)

private fun ago(ts: Long): String {
    if (ts <= 0) return "nunca conectou"
    val s = ((System.currentTimeMillis() - ts) / 1000).coerceAtLeast(0)
    return when {
        s < 60 -> "há instantes"
        s < 3600 -> "há ${s / 60} min"
        s < 86400 -> "há ${s / 3600} h"
        else -> "há ${s / 86400} dias"
    }
}
private fun typeName(t: String) = when (t) { "desktop" -> "Computador"; "mobile" -> "Celular"; "tv" -> "TV"; else -> t }

@Composable
fun AccountScreen(id: CobreId, onChanged: () -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var logged by remember { mutableStateOf(id.loggedIn) }
    var email by remember { mutableStateOf(id.email) }
    var pw by remember { mutableStateOf("") }
    var server by remember { mutableStateOf(id.server.ifEmpty { "http://" }) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf<List<Device>>(emptyList()) }

    LaunchedEffect(logged) {
        while (logged) {
            try { devices = id.devices(); err = "" }
            catch (e: Exception) {
                err = e.message ?: "Erro"
                if (!id.loggedIn) { logged = false; onChanged() }
            }
            delay(10_000)
        }
    }

    fun submit(create: Boolean) {
        busy = true; err = ""
        scope.launch {
            try { id.signIn(server, email, pw, create); pw = ""; logged = true; onChanged() }
            catch (e: Exception) { err = e.message ?: "Erro" }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("‹ Voltar", color = Cu) }
        Text("Conta Cobre", color = Tx, style = MaterialTheme.typography.headlineSmall)
        Text("Uma conta para o computador, o celular e a TV.", color = Mu, modifier = Modifier.padding(bottom = 16.dp))

        if (!logged) {
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(pw, { pw = it }, label = { Text("Senha (mínimo 8 caracteres)") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(server, { server = it }, label = { Text("Servidor do Cobre") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), modifier = Modifier.fillMaxWidth())
            if (err.isNotEmpty()) Text(err, color = Color(0xFFD1604F), modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { submit(false) }, enabled = !busy, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Cu, contentColor = Color(0xFF1A1209))) { Text("Entrar") }
                OutlinedButton(onClick = { submit(true) }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Criar conta") }
            }
        } else {
            Text(id.email, color = Tx, style = MaterialTheme.typography.titleMedium)
            Text(id.server, color = Mu, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 12.dp))
            Text("Seus dispositivos", color = Tx, style = MaterialTheme.typography.titleSmall)
            if (err.isNotEmpty()) Text(err, color = Mu, style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.weight(1f).padding(top = 8.dp)) {
                items(devices, key = { it.id }) { d ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(if (d.online) Ok else Mu))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(d.name + if (d.current) " (este)" else "", color = Tx)
                            Text("${typeName(d.type)} · " + if (d.online) "online" else "offline, visto ${ago(d.lastSeen)}",
                                color = Mu, style = MaterialTheme.typography.bodySmall)
                        }
                        if (!d.current) TextButton(onClick = {
                            scope.launch { runCatching { id.removeDevice(d.id) }; runCatching { devices = id.devices() } }
                        }) { Text("Remover", color = Mu) }
                    }
                }
            }
            OutlinedButton(onClick = { scope.launch { id.signOut(); logged = false; onChanged() } }, modifier = Modifier.fillMaxWidth()) {
                Text("Sair desta conta")
            }
        }
    }
}
